function n(text, type, time, closein) {
    timen = (time) ? time : 3500;
    bdsd = (closein) ? closein : true;
    new Noty({
        text        : text,
        type        : type,
        dismissQueue: true,
        layout      : 'bottomRight',
        theme       : 'mint',
        progressBar: true,
        timeout: timen,
        killer: bdsd
    }).show();
}

const nav = document.querySelector(".nav"),
  navOpenBtn = document.querySelector(".navOpenBtn"),
  navCloseBtn = document.querySelector(".navCloseBtn");

navOpenBtn.addEventListener("click", () => {
  nav.classList.add("openNav");
  nav.classList.remove("openSearch");
  $('body').addClass('stops');
});
navCloseBtn.addEventListener("click", () => {
  nav.classList.remove("openNav");
  $('body').removeClass('stops');
});

$(function(){
	$('.profile-btn').click(function(event) {
		$('body').addClass('stops');
		$('.pm').addClass('open');
	});
});

$(function(){
	$('.pm_close').click(function(event) {
		$('.pm').removeClass('open');
		$('body').removeClass('stops');
	});
});

$(function(){
	$('.invest--btn-banner').click(function(event) {
		$('body').addClass('stops');
		$('.vip-pay').addClass('open');
	});
});

$(function(){
	$('.vip_close').click(function(event) {
		$('.vip-pay').removeClass('open');
		$('body').removeClass('stops');
	});
});

function a(){
		n('Недоступно', 'error');
}

$(function(){
$('.btn-download').click(function(event) {
		n('Недоступно', 'error');
});
});